package com.example.fakecallsms

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Msg(val text: String, val mine: Boolean, val time: String)

@Composable
fun FakeSmsScreen() {
    var contact by remember { mutableStateOf("Budi") }
    var input by remember { mutableStateOf("") }
    var mine by remember { mutableStateOf(false) }
    val msgs = remember { mutableStateListOf<Msg>() }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Mockup SMS", style = MaterialTheme.typography.headlineSmall)
        Text("Tampilan percakapan tiruan, tidak mengirim pesan apa pun.", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(contact, { contact = it }, label = { Text("Nama kontak") }, modifier = Modifier.fillMaxWidth())

        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(msgs) { m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start) {
                    Column(
                        Modifier.widthIn(max = 280.dp)
                            .background(
                                if (m.mine) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceVariant,
                                RoundedCornerShape(16.dp)
                            ).padding(10.dp)
                    ) {
                        Text(m.text)
                        Text(m.time, style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.End))
                    }
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(mine, { mine = it })
            Spacer(Modifier.width(8.dp))
            Text(if (mine) "Dari saya" else "Dari $contact")
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { msgs.clear() }) { Text("Hapus") }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(input, { input = it }, label = { Text("Pesan") }, modifier = Modifier.weight(1f))
            Button(onClick = {
                if (input.isNotBlank()) {
                    val t = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                    msgs.add(Msg(input.trim(), mine, t)); input = ""
                }
            }) { Text("Tambah") }
        }
    }
}
