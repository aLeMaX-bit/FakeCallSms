package com.example.fakecallsms

import android.Manifest
import android.content.Intent
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun FakeCallScreen() {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("Bos") }
    var number by remember { mutableStateOf("0812 3456 7890") }
    var delay by remember { mutableStateOf("10") }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Telepon Palsu", style = MaterialTheme.typography.headlineSmall)
        Text("Panggilan tiruan yang hanya tampil di aplikasi ini.", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(name, { name = it }, label = { Text("Nama penelepon") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(number, { number = it }, label = { Text("Nomor tampilan") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(delay, { delay = it.filter(Char::isDigit) }, label = { Text("Berdering dalam (detik)") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            if (Build.VERSION.SDK_INT >= 33) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            val sec = delay.toIntOrNull() ?: 10
            CallScheduler.schedule(ctx, name, number, sec)
            Toast.makeText(ctx, "Akan berdering dalam $sec detik", Toast.LENGTH_SHORT).show()
        }, modifier = Modifier.fillMaxWidth()) { Text("Jadwalkan panggilan") }
        OutlinedButton(onClick = {
            ctx.startActivity(Intent(ctx, IncomingCallActivity::class.java)
                .putExtra("name", name).putExtra("number", number))
        }, modifier = Modifier.fillMaxWidth()) { Text("Tes sekarang") }
    }
}
