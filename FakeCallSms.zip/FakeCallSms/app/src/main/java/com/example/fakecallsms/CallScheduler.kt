package com.example.fakecallsms

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object CallScheduler {
    fun schedule(ctx: Context, name: String, number: String, delaySec: Int) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val i = Intent(ctx, CallReceiver::class.java).putExtra("name", name).putExtra("number", number)
        val pi = PendingIntent.getBroadcast(ctx, 1, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + delaySec * 1000L, pi)
    }
}
