package com.example.fakecallsms

import android.app.NotificationManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class IncomingCallActivity : ComponentActivity() {
    private var ringtone: Ringtone? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getSystemService(NotificationManager::class.java).cancel(100)
        val name = intent.getStringExtra("name") ?: "Tidak dikenal"
        val number = intent.getStringExtra("number") ?: ""
        ringtone = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))
        ringtone?.play()
        setContent { CallUi(name, number, onStopRing = { ringtone?.stop() }, onEnd = { finish() }) }
    }

    override fun onDestroy() { ringtone?.stop(); super.onDestroy() }
}

@Composable
private fun CallUi(name: String, number: String, onStopRing: () -> Unit, onEnd: () -> Unit) {
    var answered by remember { mutableStateOf(false) }
    var secs by remember { mutableIntStateOf(0) }
    LaunchedEffect(answered) {
        while (answered) { delay(1000); secs++ }
    }
    Column(
        Modifier.fillMaxSize().background(Color(0xFF101418)).padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 80.dp)) {
            Text(if (answered) "%02d:%02d".format(secs / 60, secs % 60) else "Panggilan masuk",
                color = Color.LightGray, fontSize = 16.sp)
            Spacer(Modifier.height(16.dp))
            Text(name, color = Color.White, fontSize = 34.sp)
            Text(number, color = Color.LightGray, fontSize = 18.sp)
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 48.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            Button(onClick = onEnd, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))) {
                Text(if (answered) "Akhiri" else "Tolak")
            }
            if (!answered) {
                Button(onClick = { onStopRing(); answered = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))) { Text("Angkat") }
            }
        }
    }
}
