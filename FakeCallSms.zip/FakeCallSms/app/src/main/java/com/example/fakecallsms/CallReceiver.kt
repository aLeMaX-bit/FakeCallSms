package com.example.fakecallsms

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class CallReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("call", "Panggilan tiruan", NotificationManager.IMPORTANCE_HIGH))
        val name = intent.getStringExtra("name") ?: "Tidak dikenal"
        val number = intent.getStringExtra("number") ?: ""
        val open = Intent(ctx, IncomingCallActivity::class.java)
            .putExtra("name", name).putExtra("number", number)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(ctx, 2, open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(ctx, "call")
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle(name).setContentText("Panggilan masuk")
            .setCategory(Notification.CATEGORY_CALL)
            .setContentIntent(pi).setFullScreenIntent(pi, true)
            .setAutoCancel(true).build()
        nm.notify(100, n)
    }
}
